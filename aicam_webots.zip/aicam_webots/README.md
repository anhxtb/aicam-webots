# AICAM Stereo — Webots Cloud Simulation

Mô phỏng 2 camera stereo hội tụ + tính khoảng cách đến hộp hàng trên băng chuyền.

## Cấu trúc
```
aicam_webots/
├── worlds/
│   └── aicam_stereo.wbt        ← Scene 3D
├── controllers/
│   └── aicam_controller/
│       └── aicam_controller.py ← Logic stereo vision
├── webots.yaml                 ← Config webots.cloud
├── Dockerfile                  ← Docker image
└── README.md
```

## Deploy lên webots.cloud

### Bước 1 — Tạo GitHub repo
- Vào github.com → New repository → tên: `aicam-webots`
- Upload toàn bộ thư mục này lên repo

### Bước 2 — Đăng ký trên webots.cloud
- Vào https://webots.cloud/simulation
- Click **"Add a new simulation"**
- Dán URL GitHub của file world:
  ```
  https://github.com/<your-username>/aicam-webots/blob/main/worlds/aicam_stereo.wbt
  ```
- Click **Submit**

### Bước 3 — Chạy
- Webots.cloud tự build Docker image (~2-3 phút lần đầu)
- Sau đó nhấn **Run** → simulation chạy trên browser

## Thông số mô phỏng (giống AICAM.py)
| Tham số | Giá trị |
|---|---|
| Baseline | 50 cm |
| Góc hội tụ | 10° mỗi cam |
| FOV | 60° |
| Vergence point | ~142 cm |
| Min distance | 20 cm |
| Max distance | 500 cm |

## Xem kết quả
Mở tab **Console** trong Webots → thấy khoảng cách stereo vs ground-truth mỗi giây.
