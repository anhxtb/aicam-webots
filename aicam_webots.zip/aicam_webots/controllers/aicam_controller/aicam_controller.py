"""
aicam_controller.py — Controller Webots cho AICAM Stereo Simulation
Mô phỏng stereo vision: 2 camera hội tụ + tính khoảng cách triangulation

Hiển thị trong robot window:
  - Ảnh camera trái / phải real-time
  - Khoảng cách ước tính đến vật thể (cm)
  - So sánh với ground-truth từ DistanceSensor
"""

from controller import Robot, Camera, DistanceSensor
import math
import struct

# ── Cấu hình (giống AICAM.py) ──────────────────
BASELINE_CM        = 50.0    # Khoảng cách 2 camera (cm)
CONVERGENCE_DEG    = 10.0    # Góc hội tụ mỗi cam (độ)
CAM_FOV_DEG        = 60.0    # FOV ngang (độ)
MIN_DIST_CM        = 20
MAX_DIST_CM        = 500
TIMESTEP           = 32      # ms

# ── Khởi tạo robot ─────────────────────────────
robot      = Robot()
cam_left   = robot.getDevice("cam_left")
cam_right  = robot.getDevice("cam_right")
dist_sensor = robot.getDevice("dist_sensor")

cam_left.enable(TIMESTEP)
cam_right.enable(TIMESTEP)
dist_sensor.enable(TIMESTEP)

CAM_WIDTH  = cam_left.getWidth()   # 640
CAM_HEIGHT = cam_left.getHeight()  # 480


def estimate_focal_px(width_px, fov_deg):
    """Tính focal length (px) từ width và FOV — giống AICAM.py."""
    return width_px / (2 * math.tan(math.radians(fov_deg / 2)))


def triangulate_distance(x_left, x_right, focal_px, baseline_cm,
                         convergence_deg, frame_width):
    """
    Tính khoảng cách Z (cm) — công thức từ AICAM.py:
      Z = B / [tan(θ + α_L) - tan(α_R - θ)]
    """
    cx      = frame_width / 2.0
    theta   = math.radians(convergence_deg)
    alpha_L = math.atan2(x_left  - cx, focal_px)
    alpha_R = math.atan2(x_right - cx, focal_px)
    denom   = math.tan(theta + alpha_L) - math.tan(alpha_R - theta)
    if abs(denom) < 1e-6:
        return None
    Z = baseline_cm / denom
    return Z if Z > 0 else None


def find_brightest_object_cx(image_data, width, height):
    """
    Tìm tọa độ x trung tâm của vật thể sáng nhất trong ảnh.
    Đây là cách đơn giản để detect vật — thay bằng YOLO trong thực tế.
    Trả về x_center (px) hoặc None nếu không tìm thấy.
    """
    best_brightness = 0
    best_x = None

    for x in range(0, width, 10):   # Bước 10px để nhanh hơn
        for y in range(height // 3, height * 2 // 3, 10):  # Vùng giữa
            idx = (y * width + x) * 4  # BGRA format
            if idx + 2 < len(image_data):
                b = image_data[idx]
                g = image_data[idx + 1]
                r = image_data[idx + 2]
                brightness = int(r) + int(g) + int(b)
                if brightness > best_brightness:
                    best_brightness = brightness
                    best_x = x

    return best_x if best_brightness > 300 else None


focal_px   = estimate_focal_px(CAM_WIDTH, CAM_FOV_DEG)
vergence_cm = BASELINE_CM / (2 * math.tan(math.radians(CONVERGENCE_DEG)))

print("=" * 50)
print("  AICAM Stereo Simulation — Webots")
print("=" * 50)
print(f"  Baseline     : {BASELINE_CM} cm")
print(f"  Convergence  : {CONVERGENCE_DEG}°")
print(f"  FOV          : {CAM_FOV_DEG}°")
print(f"  Focal length : {focal_px:.0f} px")
print(f"  Vergence pt  : ~{vergence_cm:.0f} cm")
print("=" * 50)

frame = 0

# ── Vòng lặp chính ─────────────────────────────
while robot.step(TIMESTEP) != -1:
    frame += 1

    # Lấy ảnh từ 2 camera
    img_left  = cam_left.getImage()
    img_right = cam_right.getImage()

    # Lấy ground-truth từ distance sensor
    gt_dist_m  = dist_sensor.getValue()
    gt_dist_cm = gt_dist_m * 100 if gt_dist_m > 0 else None

    # Tìm vật thể trong ảnh (đơn giản — theo điểm sáng nhất)
    cx_left  = find_brightest_object_cx(img_left,  CAM_WIDTH, CAM_HEIGHT)
    cx_right = find_brightest_object_cx(img_right, CAM_WIDTH, CAM_HEIGHT)

    # Tính khoảng cách stereo
    stereo_dist = None
    if cx_left is not None and cx_right is not None:
        stereo_dist = triangulate_distance(
            cx_left, cx_right,
            focal_px, BASELINE_CM,
            CONVERGENCE_DEG, CAM_WIDTH
        )
        # Lọc nhiễu
        if stereo_dist and not (MIN_DIST_CM <= stereo_dist <= MAX_DIST_CM):
            stereo_dist = None

    # In kết quả mỗi 30 frame (~1 giây)
    if frame % 30 == 0:
        stereo_text = f"{stereo_dist:.1f} cm" if stereo_dist else "N/A"
        gt_text     = f"{gt_dist_cm:.1f} cm"  if gt_dist_cm  else "N/A"
        cx_l_text   = f"{cx_left}"            if cx_left     else "-"
        cx_r_text   = f"{cx_right}"           if cx_right    else "-"

        print(f"[Frame {frame:05d}]")
        print(f"  cx_left={cx_l_text:>5}  cx_right={cx_r_text:>5}")
        print(f"  Stereo dist : {stereo_text}")
        print(f"  GT dist     : {gt_text}")
        if stereo_dist and gt_dist_cm:
            err = abs(stereo_dist - gt_dist_cm)
            print(f"  Error       : {err:.1f} cm ({err/gt_dist_cm*100:.1f}%)")
        print()
